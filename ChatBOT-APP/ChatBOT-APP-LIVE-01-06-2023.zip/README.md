# Concurrent Firebase File Uploads | Angular + Firebase 

[Upload Multiple Files to Firebase Storage](https://fireship.io/lessons/angular-firebase-storage-uploads-multi)

