export const configPlaceholder = {
  //------------ FIREBASE -------------
  apiKey: "AIzaSyDbmn8ptp4KkKJ2tQMzW3gPLrrWyoslSNo",
  authDomain: "aipdfsearch.firebaseapp.com",
  projectId: "aipdfsearch",
  storageBucket: "aipdfsearch.appspot.com",
  messagingSenderId: "904015208430",
  appId: "1:904015208430:web:a10d4ec66bbc3cbde4b8ff"
  //------------ FIREBASE -------------
};
